registerProcessor('max-processor',class extends AudioWorkletProcessor {
  process(inputList, outputList, parameters) {
    for (let inputNum = 0; inputNum < inputList.length; inputNum++) {
      let input = inputList[inputNum];
      let output = outputList[0];
      for (let channelNum = 0; channelNum < input.length; channelNum++) {
        let sampleCount = input[channelNum].length;
        for (let i = 0; i < sampleCount; i++) {
          let sample = Math.max(output[0][i],input[channelNum][i]);
          output[0][i] = sample;
        }
      }
    };
    return true;
  }
})

registerProcessor('min-processor',class extends AudioWorkletProcessor {
  process(inputList, outputList, parameters) {
    for (let inputNum = 0; inputNum < inputList.length; inputNum++) {
      let input = inputList[inputNum];
      let output = outputList[0];
      for (let channelNum = 0; channelNum < input.length; channelNum++) {
        let sampleCount = input[channelNum].length;
        for (let i = 0; i < sampleCount; i++) {
          let sample = Math.min(output[0][i],input[channelNum][i]);
          output[0][i] = sample;
        }
      }
    };
    return true;
  }
})

registerProcessor('max-signal',class extends AudioWorkletProcessor {
  static get parameterDescriptors() { return [{name:'max',defaultValue:0}] }
  process(inputList, outputList, parameters) {
    const input = inputList[0],output = outputList[0];
    for (let channel=0;channel<input.length;++channel)
      for (let i=0;i<input[channel].length;++i) output[channel][i] = Math.max(input[channel][i],parameters.max[0]);
    return true;
  }
})

registerProcessor('min-signal',class extends AudioWorkletProcessor {
  static get parameterDescriptors() { return [{name:'min',defaultValue:0}] }
  process(inputList, outputList, parameters) {
    const input = inputList[0],output = outputList[0];
    for (let channel=0;channel<input.length;++channel)
      for (let i=0;i<input[channel].length;++i) output[channel][i] = Math.min(input[channel][i],parameters.min[0]);
    return true;
  }
})
